function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Hdm1ts6DLN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

